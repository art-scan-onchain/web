const ethers = require('ethers')

const CONTRACT_ADDRESS = '0x600d4a8cf5cAEFdecA95592fBB1c48a0c5a75C7d'
// const CONTRACT_ABI = require('../lib/contracts/ArtThenticator.json').abi
const NETWORK_RPC_URL = 'https://matic-mumbai.chainstacklabs.com'

const ViewArtNft = async (_uuid) => {
  const provider = new ethers.providers.JsonRpcProvider(NETWORK_RPC_URL)
  // const wallet = new ethers.Wallet(DEPLOYER_WALLET_PRIVATE_KEY, provider)

  const abi = [
    {
      "inputs": [
        {
          "internalType": "string",
          "name": "uuid",
          "type": "string"
        }
      ],
      "name": "getIdByUUID",
      "outputs": [
        {
          "components": [
            {
              "internalType": "uint256",
              "name": "id",
              "type": "uint256"
            },
            {
              "internalType": "string",
              "name": "uuid",
              "type": "string"
            },
            {
              "internalType": "string",
              "name": "name",
              "type": "string"
            },
            {
              "internalType": "string",
              "name": "medium",
              "type": "string"
            },
            {
              "internalType": "string",
              "name": "coa",
              "type": "string"
            },
            {
              "internalType": "uint256",
              "name": "date",
              "type": "uint256"
            }
          ],
          "internalType": "struct ArtThenticator.Art",
          "name": "",
          "type": "tuple"
        }
      ],
      "stateMutability": "view",
      "type": "function"
    },
  ]

  const contract = new ethers.Contract(
    CONTRACT_ADDRESS,
    abi,
    provider
  )

  const [id, uuid, name, medium, coa, date]  = await contract.getIdByUUID(_uuid)

    if (id.toString() === '0') {
      return undefined;
    } else {
      return {
        id,
        uuid,
        name,
        medium,
        coa,
        date
      };
    }
}

// Docs on event and context https://www.netlify.com/docs/functions/#the-handler-method
const handler = async (event) => {
  try {
    // const subject = event.queryStringParameters.name || 'World'
    const [ _, uuid] = event.path.split('/view/')

    const res =  await ViewArtNft(uuid)

    return {
      statusCode: 200,
      body: JSON.stringify(res),
      // // more keys you can return:
      // headers: { "headerName": "headerValue", ... },
      // isBase64Encoded: true,
    }
  } catch (error) {
    return { statusCode: 500, body: error.toString() }
  }
}

module.exports = { handler, ViewArtNft }
